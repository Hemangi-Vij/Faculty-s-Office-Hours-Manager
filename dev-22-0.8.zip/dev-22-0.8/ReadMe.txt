Name of application: OfficeSync

Version: 0.8

Who did what:
1.Polymorphism  (Alex S)
2.Edit Function (Hemangi Vij)
3.Edit Function (Ryan Cartwright)
4.Edit Function  (Timmy Chen)


Any other instruction that users need to know:
Polymorphism is used in the ScheduleParent (Parent) and ScheduleEntry (Child) class and a demo is
in the main