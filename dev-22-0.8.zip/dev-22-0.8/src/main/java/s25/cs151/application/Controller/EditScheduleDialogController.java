package s25.cs151.application.Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import s25.cs151.application.Model.ScheduleEntry;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class EditScheduleDialogController {
    @FXML private TextField studentNameField;
    @FXML private DatePicker scheduleDatePicker;
    @FXML private ComboBox<String> timeSlotComboBox;
    @FXML private ComboBox<String> courseComboBox;
    @FXML private TextField reasonField;
    @FXML private TextField commentField;

    private static final String TIME_SLOTS_FILE = "/data/time_slots.txt";
    private static final String COURSES_FILE = "/data/courses.txt";

    private ScheduleEntry originalEntry;
    private EditSchedulesController parentController;

    @FXML
    public void initialize() {
        loadTimeSlots();
        loadCourses();
    }

    private void loadTimeSlots() {
        try (InputStream is = getClass().getResourceAsStream(TIME_SLOTS_FILE);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            timeSlotComboBox.getItems().clear();
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    timeSlotComboBox.getItems().add(parts[0] + " - " + parts[1]);
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Failed to load time slots");
        }
    }

    private void loadCourses() {
        try (InputStream is = getClass().getResourceAsStream(COURSES_FILE);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            courseComboBox.getItems().clear();
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    courseComboBox.getItems().add(parts[0] + " - " + parts[2]);
                }
            }
        } catch (IOException e) {
            showAlert("Error", "Failed to load courses");
        }
    }

    public void setScheduleEntry(ScheduleEntry entry) {
        this.originalEntry = entry;

        studentNameField.setText(entry.getStudentName());
        scheduleDatePicker.setValue(entry.getScheduleDate());
        timeSlotComboBox.setValue(entry.getTimeSlot());
        courseComboBox.setValue(entry.getCourse());
        reasonField.setText(entry.getReason());
        commentField.setText(entry.getComment());
    }

    public void setParentController(EditSchedulesController controller) {
        this.parentController = controller;
    }

    @FXML
    private void handleSave() {
        if (validateInput()) {
            updateOriginalEntry();
            parentController.saveSchedulesToFile();
            parentController.refreshData();
            closeWindow();
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private void updateOriginalEntry() {
        originalEntry.setStudentName(studentNameField.getText());
        originalEntry.setScheduleDate(scheduleDatePicker.getValue());
        originalEntry.setTimeSlot(timeSlotComboBox.getValue());
        originalEntry.setCourse(courseComboBox.getValue());
        originalEntry.setReason(reasonField.getText());
        originalEntry.setComment(commentField.getText());
    }

    private boolean validateInput() {
        if (studentNameField.getText().isEmpty() ||
                scheduleDatePicker.getValue() == null ||
                timeSlotComboBox.getValue() == null ||
                courseComboBox.getValue() == null) {

            showAlert("Error", "Required fields cannot be empty");
            return false;
        }
        return true;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void closeWindow() {
        ((Stage) studentNameField.getScene().getWindow()).close();
    }
}
