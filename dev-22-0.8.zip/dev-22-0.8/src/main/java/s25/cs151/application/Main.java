package s25.cs151.application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import s25.cs151.application.Model.ScheduleEntry;
import s25.cs151.application.Model.ScheduleParent;

import java.io.IOException;
import java.time.LocalDate;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("OfficeSync");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        showPolymorphismDemo();
        launch();
    }

    public static void showPolymorphismDemo() {
        ScheduleParent entry = new ScheduleEntry("Alice", LocalDate.now(), "09:00 - 10:00", "CS151", "Help", "N/A");
        System.out.println(entry.getDisplayInfo());
    }
}