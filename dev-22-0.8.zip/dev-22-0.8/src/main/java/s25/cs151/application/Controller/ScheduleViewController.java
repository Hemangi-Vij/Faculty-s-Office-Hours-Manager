package s25.cs151.application.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import s25.cs151.application.Model.ScheduleEntry;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ScheduleViewController {
    @FXML private TableView<ScheduleEntry> scheduleTable;
    @FXML private TableColumn<ScheduleEntry, String> studentNameColumn;
    @FXML private TableColumn<ScheduleEntry, LocalDate> dateColumn;
    @FXML private TableColumn<ScheduleEntry, String> timeSlotColumn;
    @FXML private TableColumn<ScheduleEntry, String> courseColumn;
    @FXML private TableColumn<ScheduleEntry, String> reasonColumn;
    @FXML private TableColumn<ScheduleEntry, String> commentColumn;
    @FXML private TextField searchField;

    private static final String SCHEDULE_FILE_PATH = "src/main/resources/data/schedules.txt";
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;

    private ObservableList<ScheduleEntry> allSchedules = FXCollections.observableArrayList();
    private FilteredList<ScheduleEntry> filteredSchedules;

    @FXML
    public void initialize() {
        configureTableColumns();
        loadScheduleData();
        setupFilteredList();

        dateColumn.setSortType(TableColumn.SortType.DESCENDING);
        timeSlotColumn.setSortType(TableColumn.SortType.DESCENDING);

        scheduleTable.getSortOrder().clear();
        scheduleTable.getSortOrder().addAll(dateColumn, timeSlotColumn);

        scheduleTable.sort();
    }


    private void configureTableColumns() {
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("scheduleDate"));
        timeSlotColumn.setCellValueFactory(new PropertyValueFactory<>("timeSlot"));
        courseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        reasonColumn.setCellValueFactory(new PropertyValueFactory<>("reason"));
        commentColumn.setCellValueFactory(new PropertyValueFactory<>("comment"));
    }

    private void loadScheduleData() {
        allSchedules.clear();
        File scheduleFile = new File(SCHEDULE_FILE_PATH);

        if (scheduleFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(scheduleFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",", 6);
                    if (parts.length == 6) {
                        allSchedules.add(new ScheduleEntry(
                                parts[0],
                                LocalDate.parse(parts[1], dateFormatter),
                                parts[2],
                                parts[3],
                                parts[4],
                                parts[5]
                        ));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void setupFilteredList() {
        filteredSchedules = new FilteredList<>(allSchedules, p -> true);
        SortedList<ScheduleEntry> sortedSchedules = new SortedList<>(filteredSchedules);

        sortedSchedules.comparatorProperty().bind(scheduleTable.comparatorProperty());
        scheduleTable.setItems(sortedSchedules);

        dateColumn.setSortType(TableColumn.SortType.DESCENDING);
        timeSlotColumn.setSortType(TableColumn.SortType.DESCENDING);
        scheduleTable.getSortOrder().clear();
        scheduleTable.getSortOrder().addAll(dateColumn, timeSlotColumn);
        scheduleTable.sort();
    }

    private void sortData() {
        scheduleTable.getSortOrder().addAll(dateColumn, timeSlotColumn);
        dateColumn.setSortType(TableColumn.SortType.DESCENDING);
        timeSlotColumn.setSortType(TableColumn.SortType.DESCENDING);
    }

    @FXML
    private void handleSearch() {
        String query = searchField.getText().toLowerCase();
        filteredSchedules.setPredicate(schedule ->
                schedule.getStudentName().toLowerCase().contains(query)
        );
    }

    @FXML
    private void handleDeleteSelected() {
        ScheduleEntry selected = scheduleTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            allSchedules.remove(selected);
            saveSchedulesToFile();
            scheduleTable.refresh();
        }
    }

    public void saveSchedulesToFile() {
        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(SCHEDULE_FILE_PATH, false))) {
            for (ScheduleEntry entry : allSchedules) {
                writer.write(String.join(",",
                        entry.getStudentName(),
                        entry.getScheduleDate().toString(),
                        entry.getTimeSlot(),
                        entry.getCourse(),
                        entry.getReason(),
                        entry.getComment()
                ));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
