package s25.cs151.application.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import s25.cs151.application.Model.ScheduleEntry;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EditSchedulesController {
    @FXML private TableView<ScheduleEntry> schedulesTable;
    @FXML private TableColumn<ScheduleEntry, String> studentNameColumn;
    @FXML private TableColumn<ScheduleEntry, LocalDate> dateColumn;
    @FXML private TableColumn<ScheduleEntry, String> timeSlotColumn;
    @FXML private TableColumn<ScheduleEntry, String> courseColumn;
    @FXML private TableColumn<ScheduleEntry, String> reasonColumn;
    @FXML private TableColumn<ScheduleEntry, String> commentColumn;
    @FXML private TextField searchField;

    private static final String SCHEDULE_FILE_PATH = "src/main/resources/data/schedules.txt";
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
    private ObservableList<ScheduleEntry> allSchedules = FXCollections.observableArrayList();
    private FilteredList<ScheduleEntry> filteredSchedules;

    @FXML
    public void initialize() {
        configureTableColumns();
        loadScheduleData();
        setupFilteredList();
        applyDefaultSorting();
    }

    private void configureTableColumns() {
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("scheduleDate"));
        timeSlotColumn.setCellValueFactory(new PropertyValueFactory<>("timeSlot"));
        courseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        reasonColumn.setCellValueFactory(new PropertyValueFactory<>("reason"));
        commentColumn.setCellValueFactory(new PropertyValueFactory<>("comment"));
    }

    private void loadScheduleData() {
        allSchedules.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(SCHEDULE_FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 6);
                if (parts.length == 6) {
                    allSchedules.add(new ScheduleEntry(
                            parts[0],
                            LocalDate.parse(parts[1], dateFormatter),
                            parts[2],
                            parts[3],
                            parts[4],
                            parts[5]
                    ));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupFilteredList() {
        filteredSchedules = new FilteredList<>(allSchedules, p -> true);
        SortedList<ScheduleEntry> sortedSchedules = new SortedList<>(filteredSchedules);
        sortedSchedules.comparatorProperty().bind(schedulesTable.comparatorProperty());
        schedulesTable.setItems(sortedSchedules);
    }

    private void applyDefaultSorting() {
        dateColumn.setSortType(TableColumn.SortType.DESCENDING);
        timeSlotColumn.setSortType(TableColumn.SortType.DESCENDING);
        schedulesTable.getSortOrder().setAll(dateColumn, timeSlotColumn);
    }

    @FXML
    private void handleSearch() {
        String query = searchField.getText().toLowerCase();
        filteredSchedules.setPredicate(schedule ->
                schedule.getStudentName().toLowerCase().contains(query)
        );
    }

    @FXML
    private void handleClearSearch() {
        searchField.clear();
        filteredSchedules.setPredicate(null);
    }

    @FXML
    private void handleEditSelected() {
        ScheduleEntry selected = schedulesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a schedule to edit");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/s25/cs151/application/edit-schedule-dialog.fxml"));
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(loader.load()));

            EditScheduleDialogController controller = loader.getController();
            controller.setScheduleEntry(selected);
            controller.setParentController(this);

            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToHome() {
        ((Stage) schedulesTable.getScene().getWindow()).close();
    }

    public void saveSchedulesToFile() {
        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(SCHEDULE_FILE_PATH, false))) {
            for (ScheduleEntry entry : allSchedules) {
                writer.write(String.join(",",
                        entry.getStudentName(),
                        entry.getScheduleDate().toString(),
                        entry.getTimeSlot(),
                        entry.getCourse(),
                        entry.getReason(),
                        entry.getComment()
                ));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to save schedules");
        }
    }

    public void refreshData() {
        filteredSchedules.setPredicate(null);
        filteredSchedules.setPredicate(p -> true);
        schedulesTable.refresh();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
