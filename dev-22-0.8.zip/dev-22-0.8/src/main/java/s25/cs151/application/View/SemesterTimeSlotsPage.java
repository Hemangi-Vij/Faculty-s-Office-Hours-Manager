package s25.cs151.application.View;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;

public class SemesterTimeSlotsPage {
    @FXML
    private ComboBox<String> fromHourPicker;

    @FXML
    private ComboBox<String> toHourPicker;

    @FXML
    private TableView<TimeSlotEntry> timeSlotTable;

    @FXML
    private TableColumn<TimeSlotEntry, String> fromHourColumn;

    @FXML
    private TableColumn<TimeSlotEntry, String> toHourColumn;

    private ObservableList<String> timeIntervals;

    public void initialize() {
        // 15 min intervals
        timeIntervals = generateTimeIntervals();
        fromHourPicker.setItems(timeIntervals);
        toHourPicker.setItems(timeIntervals);

        // table columns
        fromHourColumn.setCellValueFactory(new PropertyValueFactory<>("fromHour"));
        toHourColumn.setCellValueFactory(new PropertyValueFactory<>("toHour"));

        // Load existing time slots from file
        ObservableList<TimeSlotEntry> timeSlots = loadTimeSlotsFromFile();
        timeSlotTable.setItems(timeSlots);
    }

    @FXML
    protected void onSaveButtonClick() {
        String fromHour = fromHourPicker.getValue();
        String toHour = toHourPicker.getValue();

        if (fromHour == null || toHour == null) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Both 'From Hour' and 'To Hour' must be selected.");
            return;
        }

        // To Hour is after the From Hour
        if (timeIntervals.indexOf(toHour) <= timeIntervals.indexOf(fromHour)) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "'To Hour' must be later than 'From Hour'.");
            return;
        }

        // code to prevent duplicates
        ObservableList<TimeSlotEntry> existingEntries = timeSlotTable.getItems();
        for (TimeSlotEntry entry : existingEntries) {
            if (entry.getFromHour().equals(fromHour) && entry.getToHour().equals(toHour)) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Entry", "This time slot already exists.");
                return;
            }
        }

        // Save
        saveTimeSlotToFile(fromHour, toHour);

        // Update table
        timeSlotTable.getItems().add(new TimeSlotEntry(fromHour, toHour));
    }

    private ObservableList<String> generateTimeIntervals() {
        ObservableList<String> intervals = FXCollections.observableArrayList();
        for (int hour = 6; hour <= 21; hour++) { // Office hours: 6 AM to 9 PM
            for (int minute = 0; minute < 60; minute += 15) { // 15-minute intervals
                intervals.add(String.format("%02d:%02d", hour, minute));
            }
        }
        return intervals;
    }

    private ObservableList<TimeSlotEntry> loadTimeSlotsFromFile() {
        ObservableList<TimeSlotEntry> entries = FXCollections.observableArrayList();
        try {
            // getting .txt from data folder
            InputStream inputStream = getClass().getResourceAsStream("/data/time_slots.txt");
            if (inputStream == null) {
                throw new FileNotFoundException("time_slots.txt not found in resources/data folder.");
            }

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    entries.add(new TimeSlotEntry(parts[0], parts[1]));
                }
            }
            bufferedReader.close();

            // Sort ascending by From Hour
            entries.sort((e1, e2) -> e1.getFromHour().compareTo(e2.getFromHour()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return entries;
    }

    private static final String FILE_PATH = "src/main/resources/data/time_slots.txt";

    private void saveTimeSlotToFile(String fromHour, String toHour) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(fromHour + "," + toHour);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static class TimeSlotEntry {
        private final String fromHour;
        private final String toHour;

        public TimeSlotEntry(String fromHour, String toHour) {
            this.fromHour = fromHour;
            this.toHour = toHour;
        }

        public String getFromHour() { return fromHour; }
        public String getToHour() { return toHour; }
    }
}
