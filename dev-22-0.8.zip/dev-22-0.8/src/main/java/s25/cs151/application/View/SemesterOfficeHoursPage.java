package s25.cs151.application.View;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.URISyntaxException;

public class SemesterOfficeHoursPage {

    @FXML
    private ComboBox<String> semesterDropdown;

    @FXML
    private TextField yearInput;

    @FXML
    private CheckBox mondayCheckbox;

    @FXML
    private CheckBox tuesdayCheckbox;

    @FXML
    private CheckBox wednesdayCheckbox;

    @FXML
    private CheckBox thursdayCheckbox;

    @FXML
    private CheckBox fridayCheckbox;

    private static final String FILE_PATH = "/data/office_hours.txt";

    @FXML
    public void initialize() {
        // Fill in the semester dropdown
        semesterDropdown.getItems().addAll("Spring", "Summer", "Fall", "Winter");

        // Year input validation (only numbers and 4 digits)
        yearInput.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                yearInput.setText(newValue.replaceAll("[^\\d]", "")); // Remove non-numeric characters
            }
            if (newValue.length() > 4) {
                yearInput.setText(newValue.substring(0, 4)); // Limit to 4 digits
            }
        });
    }

    @FXML
    protected void onSubmitButtonClick() {
        if (semesterDropdown.getValue() == null || yearInput.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Missing Required Fields", "Please select a semester and enter a year.");
            return;
        }

        StringBuilder selectedDays = new StringBuilder();
        if (mondayCheckbox.isSelected()) selectedDays.append("Monday,");
        if (tuesdayCheckbox.isSelected()) selectedDays.append("Tuesday,");
        if (wednesdayCheckbox.isSelected()) selectedDays.append("Wednesday,");
        if (thursdayCheckbox.isSelected()) selectedDays.append("Thursday,");
        if (fridayCheckbox.isSelected()) selectedDays.append("Friday,");

        if (selectedDays.length() > 0) {
            selectedDays.setLength(selectedDays.length() - 1); // Remove trailing comma
        } else {
            selectedDays.append("None");
        }

        String semester = semesterDropdown.getValue();
        String year = yearInput.getText();

        // Prevent duplicates
        if (isDuplicateEntry(semester, year)) {
            showAlert(Alert.AlertType.ERROR, "Duplicate Entry", "This semester and year combination already exists.", null);
            return;
        }

        // Save data
        saveOfficeHoursToFile(semester, year, selectedDays.toString());

        // confirmation alert
        showAlert(Alert.AlertType.INFORMATION, "Submission Successful", "Office Hours Set",
                "Semester: " + semester + "\nYear: " + year + "\nDays: " + selectedDays);

        // Navigate back to the home page
        navigateToHomePage();
    }

    private boolean isDuplicateEntry(String semester, String year) {
        try {
            InputStream inputStream = getClass().getResourceAsStream(FILE_PATH);
            if (inputStream == null) {
                return false; // File doesn't exist yet, no duplicates possible
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length >= 2 && parts[0].equals(semester) && parts[1].equals(year)) {
                    reader.close();
                    return true; // Duplicate found
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void saveOfficeHoursToFile(String semester, String year, String days) {
        try {
            File file = new File(getClass().getResource(FILE_PATH).toURI());
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write(semester + "," + year + "," + days);
            writer.newLine();
            writer.close();
        } catch (URISyntaxException | IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "File Error", null, "Failed to save office hours.");
        }
    }

    private void navigateToHomePage() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            Stage stage = (Stage) yearInput.getScene().getWindow(); // Get current stage
            stage.setScene(scene); // Set homepage scene on current stage
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String headerText, String contentText) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
}
