package s25.cs151.application.Model;

public class CourseEntry {
    private final String courseCode;
    private final String courseName;
    private final String sectionNumber;

    public CourseEntry(String courseCode, String courseName, String sectionNumber) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.sectionNumber = sectionNumber;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getSectionNumber() {
        return sectionNumber;
    }
}
