package s25.cs151.application.Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.*;
import java.time.LocalDate;

public class ScheduleOfficeHoursController {
    @FXML private TextField studentNameField;
    @FXML private DatePicker scheduleDatePicker;
    @FXML private ComboBox<String> timeSlotComboBox;
    @FXML private ComboBox<String> courseComboBox;
    @FXML private TextField reasonField;
    @FXML private TextField commentField;

    private static final String SCHEDULE_FILE_PATH = "src/main/resources/data/schedules.txt";
    private static final String TIME_SLOTS_FILE = "/data/time_slots.txt";
    private static final String COURSES_FILE = "/data/courses.txt";

    @FXML
    public void initialize() {
        loadTimeSlots();
        loadCourses();
        scheduleDatePicker.setValue(LocalDate.now());
    }

    private void loadTimeSlots() {
        try (InputStream is = getClass().getResourceAsStream(TIME_SLOTS_FILE);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    timeSlotComboBox.getItems().add(parts[0] + " - " + parts[1]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load time slots.");
        }
    }

    private void loadCourses() {
        try (InputStream is = getClass().getResourceAsStream(COURSES_FILE);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    courseComboBox.getItems().add(parts[0] + " - " + parts[2]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load courses.");
        }
    }

    @FXML
    protected void onSaveScheduleClick() {
        if (validateInput()) {
            saveSchedule();
            closeWindow();
        }
    }

    private boolean validateInput() {
        if (studentNameField.getText() == null || studentNameField.getText().isEmpty() ||
                scheduleDatePicker.getValue() == null ||
                timeSlotComboBox.getValue() == null ||
                courseComboBox.getValue() == null) {

            showAlert("Error", "Required fields cannot be empty.");
            return false;
        }
        return true;
    }

    private void saveSchedule() {
        File scheduleFile = new File(SCHEDULE_FILE_PATH);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(scheduleFile, true))) {
            String reason = reasonField.getText() == null || reasonField.getText().isEmpty() ? "N/A" : reasonField.getText();
            String comment = commentField.getText() == null || commentField.getText().isEmpty() ? "N/A" : commentField.getText();

            String record = String.join(",",
                    studentNameField.getText(),
                    scheduleDatePicker.getValue().toString(),
                    timeSlotComboBox.getValue(),
                    courseComboBox.getValue(),
                    reason,
                    comment
            );

            writer.write(record);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to save schedule.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void closeWindow() {
        ((Stage) studentNameField.getScene().getWindow()).close();
    }
}
