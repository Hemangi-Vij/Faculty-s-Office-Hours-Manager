// ScheduleEntry.java
package s25.cs151.application.Model;

import java.time.LocalDate;
import java.util.Objects;

public class ScheduleEntry extends ScheduleParent {
    private String studentName;
    private LocalDate scheduleDate;
    private String timeSlot;
    private String course;
    private String reason;
    private String comment;

    public ScheduleEntry(String studentName, LocalDate scheduleDate, String timeSlot, String course, String reason, String comment) {
        this.studentName = studentName;
        this.scheduleDate = scheduleDate;
        this.timeSlot = timeSlot;
        this.course = course;
        this.reason = reason;
        this.comment = comment;
    }

    public String getStudentName() { return studentName; }
    public LocalDate getScheduleDate() { return scheduleDate; }
    public String getTimeSlot() { return timeSlot; }
    public String getCourse() { return course; }
    public String getReason() { return reason; }
    public String getComment() { return comment; }

    public void setStudentName(String studentName) { this.studentName = studentName; }
    public void setScheduleDate(LocalDate scheduleDate) { this.scheduleDate = scheduleDate; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
    public void setCourse(String course) { this.course = course; }
    public void setReason(String reason) { this.reason = reason; }
    public void setComment(String comment) { this.comment = comment; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ScheduleEntry that = (ScheduleEntry) o;
        return Objects.equals(studentName, that.studentName) &&
                Objects.equals(scheduleDate, that.scheduleDate) &&
                Objects.equals(timeSlot, that.timeSlot) &&
                Objects.equals(course, that.course);
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentName, scheduleDate, timeSlot, course);
    }
    @Override
    public String getDisplayInfo() {
        return "Student: " + studentName + ", Date: " + scheduleDate;
    }


}
