package s25.cs151.application.Model;

public abstract class ScheduleParent {
    public abstract String getDisplayInfo();
}
