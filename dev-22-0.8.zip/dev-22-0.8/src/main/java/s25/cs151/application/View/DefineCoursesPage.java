package s25.cs151.application.View;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import s25.cs151.application.Model.CourseEntry;

import java.io.*;

public class DefineCoursesPage {
    @FXML
    private TextField courseCodeInput;

    @FXML
    private TextField courseNameInput;

    @FXML
    private TextField sectionNumberInput;

    @FXML
    private TableView<CourseEntry> courseTable;

    @FXML
    private TableColumn<CourseEntry, String> courseCodeColumn;

    @FXML
    private TableColumn<CourseEntry, String> courseNameColumn;

    @FXML
    private TableColumn<CourseEntry, String> sectionNumberColumn;

    private static final String FILE_PATH = "/data/courses.txt";

    public void initialize() {
        // table columns
        courseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        courseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        sectionNumberColumn.setCellValueFactory(new PropertyValueFactory<>("sectionNumber"));

        // Load existing courses
        ObservableList<CourseEntry> courses = loadCoursesFromFile();
        courseTable.setItems(courses);
    }

    @FXML
    protected void onSaveButtonClick() {
        String courseCode = courseCodeInput.getText().trim();
        String courseName = courseNameInput.getText().trim();
        String sectionNumber = sectionNumberInput.getText().trim();

        if (courseCode.isEmpty() || courseName.isEmpty() || sectionNumber.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "All fields are required.");
            return;
        }

        // Prevent duplicates
        ObservableList<CourseEntry> existingEntries = courseTable.getItems();
        for (CourseEntry entry : existingEntries) {
            if (entry.getCourseCode().equals(courseCode) &&
                    entry.getCourseName().equals(courseName) &&
                    entry.getSectionNumber().equals(sectionNumber)) {
                showAlert(Alert.AlertType.ERROR, "Duplicate Entry",
                        "This course combination already exists.");
                return;
            }
        }

        // Save
        saveCourseToFile(courseCode, courseName, sectionNumber);

        // Update table view
        CourseEntry newCourse = new CourseEntry(courseCode, courseName, sectionNumber);
        courseTable.getItems().add(newCourse);

        // Descending order by course code
        FXCollections.sort(courseTable.getItems(), (c1, c2) -> c2.getCourseCode().compareTo(c1.getCourseCode()));

        // Clear input fields after saving
        clearInputs();
    }

    private ObservableList<CourseEntry> loadCoursesFromFile() {
        ObservableList<CourseEntry> entries = FXCollections.observableArrayList();
        try {
            // locate the file in the data folder
            InputStream inputStream = getClass().getResourceAsStream(FILE_PATH);
            if (inputStream == null) {
                throw new FileNotFoundException("courses.txt not found in resources/data folder.");
            }

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length == 3) {
                    entries.add(new CourseEntry(parts[0], parts[1], parts[2]));
                }
            }
            bufferedReader.close();

            // descending order by course code
            FXCollections.sort(entries, (c1, c2) -> c2.getCourseCode().compareTo(c1.getCourseCode()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return entries;
    }

    private void saveCourseToFile(String courseCode, String courseName, String sectionNumber) {
        try {
            // Save data
            File file = new File("src/main/resources/data/courses.txt"); // Writable location in resources/data folder
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write(courseCode + "," + courseName + "," + sectionNumber);
            writer.newLine();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "File Error", "Failed to save the course.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void clearInputs() {
        courseCodeInput.clear();
        courseNameInput.clear();
        sectionNumberInput.clear();
    }
}
