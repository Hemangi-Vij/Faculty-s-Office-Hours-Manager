package s25.cs151.application.View;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class OfficeHourView {
    @FXML
    private TableView<OfficeHourEntry> tableView;

    @FXML
    private TableColumn<OfficeHourEntry, String> semesterColumn;

    @FXML
    private TableColumn<OfficeHourEntry, Integer> yearColumn;

    @FXML
    private TableColumn<OfficeHourEntry, String> daysColumn;

    private static final String FILE_PATH = "/data/office_hours.txt";

    public void initialize() {
        // Set up columns
        semesterColumn.setCellValueFactory(new PropertyValueFactory<>("semester"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        daysColumn.setCellValueFactory(new PropertyValueFactory<>("days"));

        // Load data from file
        ObservableList<OfficeHourEntry> entries = loadOfficeHoursFromFile();
        tableView.setItems(entries);
    }

    private ObservableList<OfficeHourEntry> loadOfficeHoursFromFile() {
        ObservableList<OfficeHourEntry> entries = FXCollections.observableArrayList();
        try {
            // Use getClass().getResourceAsStream() to locate the file in the resources/data folder
            InputStream inputStream = getClass().getResourceAsStream(FILE_PATH);
            if (inputStream == null) {
                throw new FileNotFoundException("office_hours.txt not found in resources/data folder.");
            }

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",", 3); // Split into Semester, Year, Days
                if (parts.length == 3) {
                    String semester = parts[0];
                    int year = Integer.parseInt(parts[1]);
                    String days = parts[2];
                    entries.add(new OfficeHourEntry(semester, year, days));
                }
            }
            bufferedReader.close();

            // Sort descending by year and semester
            entries.sort((e1, e2) -> {
                int yearCompare = Integer.compare(e2.getYear(), e1.getYear());
                if (yearCompare != 0) return yearCompare;
                return e2.getSemester().compareTo(e1.getSemester());
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        return entries;
    }

    public static class OfficeHourEntry {
        private final String semester;
        private final int year;
        private final String days;

        public OfficeHourEntry(String semester, int year, String days) {
            this.semester = semester;
            this.year = year;
            this.days = days;
        }

        public String getSemester() {
            return semester;
        }

        public int getYear() {
            return year;
        }

        public String getDays() {
            return days;
        }
    }
}
