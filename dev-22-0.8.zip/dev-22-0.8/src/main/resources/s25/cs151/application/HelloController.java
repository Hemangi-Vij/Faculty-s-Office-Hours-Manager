package s25.cs151.application;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HelloController {
    @FXML
    private Label welcomeText;

    public HelloController() {
    }

    @FXML
    protected void onHelloButtonClick() {
        this.welcomeText.setText("Welcome to OfficeSync!");
    }

    @FXML
    protected void onOfficeHourButtonClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("semester-office-hours.fxml"));
            Scene scene = new Scene((Parent)fxmlLoader.load(), (double)320.0F, (double)400.0F);
            Stage stage = new Stage();
            stage.setTitle("Semester Office Hours");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
