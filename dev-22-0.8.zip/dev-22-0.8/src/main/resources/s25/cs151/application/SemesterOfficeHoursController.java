package s25.cs151.application;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class SemesterOfficeHoursController {
    @FXML
    private ComboBox<String> semesterDropdown;
    @FXML
    private TextField yearInput;
    @FXML
    private CheckBox mondayCheckbox;
    @FXML
    private CheckBox tuesdayCheckbox;
    @FXML
    private CheckBox wednesdayCheckbox;
    @FXML
    private CheckBox thursdayCheckbox;
    @FXML
    private CheckBox fridayCheckbox;

    public SemesterOfficeHoursController() {
    }

    @FXML
    public void initialize() {
        this.semesterDropdown.getItems().addAll(new String[]{"Spring", "Summer", "Fall", "Winter"});
        this.yearInput.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                this.yearInput.setText(newValue.replaceAll("[^\\d]", ""));
            }

        });
    }

    @FXML
    protected void onSubmitButtonClick() {
        if (this.semesterDropdown.getValue() != null && !this.yearInput.getText().isEmpty()) {
            StringBuilder selectedDays = new StringBuilder("Selected days: ");
            boolean anyDaySelected = false;
            if (this.mondayCheckbox.isSelected()) {
                selectedDays.append("Monday, ");
                anyDaySelected = true;
            }

            if (this.tuesdayCheckbox.isSelected()) {
                selectedDays.append("Tuesday, ");
                anyDaySelected = true;
            }

            if (this.wednesdayCheckbox.isSelected()) {
                selectedDays.append("Wednesday, ");
                anyDaySelected = true;
            }

            if (this.thursdayCheckbox.isSelected()) {
                selectedDays.append("Thursday, ");
                anyDaySelected = true;
            }

            if (this.fridayCheckbox.isSelected()) {
                selectedDays.append("Friday, ");
                anyDaySelected = true;
            }

            if (anyDaySelected) {
                selectedDays.setLength(selectedDays.length() - 2);
            } else {
                selectedDays.append("None");
            }

            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Submission Successful");
            alert.setHeaderText("Office Hours Set");
            String var10001 = (String)this.semesterDropdown.getValue();
            alert.setContentText("Semester: " + var10001 + "\nYear: " + this.yearInput.getText() + "\n" + selectedDays.toString());
            alert.showAndWait();
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Input Error");
            alert.setHeaderText("Missing Required Fields");
            alert.setContentText("Please select a semester and enter a year.");
            alert.showAndWait();
        }
    }
}
